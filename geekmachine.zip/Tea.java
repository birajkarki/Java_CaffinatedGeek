import java.util.Set;

public class Tea {
    public static final int DEFAULT_STEEPING_TIME = 0;
    public static final int DEFAULT_ID = 0;
    // Instance variables
    private final int menuId;
    private final String menuName;
    private final int temperature;
    private final int steepingTime;
    private final Sugar sugar;
    private final Set<Milk> milk;
    private final Set<Extras> extras;
    private String description; // Change from final to non-final


    // Sugar enum
    public enum Sugar {
        YES("Yes"),
        NO("No"),
        DONT_MIND("I don't mind");

        private final String label;

        Sugar(String label) {
            this.label = label;
        }

        @Override
        public String toString() {
            return label;
        }
    }

    // Milk enum
    public enum Milk {
        FULL_CREAM("Full Cream"),
        SKIMMED("Skimmed"),
        ALMOND("Almond"),
        SOY("Soy"),
        COCONUT("Coconut");

        private final String label;

        Milk(String label) {
            this.label = label;
        }

        @Override
        public String toString() {
            return label;
        }
    }

    // Extras enum
    public enum Extras {
        WHIPPED_CREAM("Whipped Cream"),
        CHOCOLATE_SYRUP("Chocolate Syrup"),
        CARAMEL_SYRUP("Caramel Syrup"),
        VANILLA_SYRUP("Vanilla Syrup");

        private final String label;

        Extras(String label) {
            this.label = label;
        }

        @Override
        public String toString() {
            return label;
        }
    }

    // Constructor
    public Tea(int menuId, String menuName, int temperature, int steepingTime, Tea.Sugar sugar, Set<Milk> milk, Set<Extras> extras) {
        this.menuId = menuId;
        this.menuName = menuName;
        this.temperature = temperature;
        this.steepingTime = steepingTime;
        this.sugar = sugar;
        this.milk = milk;
        this.extras = extras;
    }
    // Getters
    public int getMenuId() {
        return menuId;
    }

    public String getMenuName() {
        return menuName;
    }

    public int getTemperature() {
        return temperature;
    }

    public int getSteepingTime() {
        return steepingTime;
    }

    public Sugar getSugar() {
        return sugar;
    }

    public Set<Milk> getMilk() {
        return milk;
    }

    public Set<Extras> getExtras() {
        return extras;
    }

    public String getDescription() {
        return description;
    }

   
}
